// Para los imports.

const NuevoFeo = () => {
  // Javascript.

  return (
    // JSX.
    <>
      <p>Hola.</p>
      <p>Hola.</p>
    </>
  );
};

export default NuevoFeo;
